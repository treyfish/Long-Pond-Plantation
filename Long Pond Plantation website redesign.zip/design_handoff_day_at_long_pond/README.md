# Handoff: "A Day at Long Pond" — Scroll-Pinned Story Section

## Overview
A single, self-contained hero/story section for the Long Pond Plantation wedding-venue website. As the user scrolls through it, a full-viewport image "pins" in place and cross-fades through four scenes of a wedding day (morning → ceremony → golden hour → last dance). A caption block (time, title, description) and a progress bar update in sync with scroll position.

This is the standalone version of the feature the client liked, extracted from the full homepage prototype.

## About the Design Files
The files in this bundle are **design references created in HTML** — a working prototype showing the intended look and behavior, not production code to ship as-is. The task is to **recreate this section in the target codebase's existing environment** (React, Vue, Svelte, SwiftUI, plain JS, etc.) using its established patterns, component conventions, and image-loading approach. If no environment exists yet, pick the most appropriate framework and implement it there.

`day_at_long_pond.html` opens directly in a browser and is fully functional — use it to feel the interaction and read exact values.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, timing, and the scroll math are all production-intent. Recreate pixel-for-pixel, swapping in the codebase's own image pipeline and (optionally) its scroll/animation utilities.

## Screens / Views

### Scene: "A Day at Long Pond" (single pinned section)
- **Purpose**: An emotional, cinematic walkthrough of a wedding day at the venue — the "wow" moment of the site. Communicates the property's range (estate home, oak ceremony lawn, pond at golden hour, barn at night) and the Woodys Coffee perk, in one scroll.
- **Layout**:
  - Outer `<section>`: `position: relative; height: 420vh;` background `#0e110b`. The tall height creates the scroll distance.
  - Inner wrapper: `position: sticky; top: 0; height: 100vh; overflow: hidden;` — this pins to the viewport while the outer section scrolls past.
  - Four `<img>` elements stacked absolutely (`inset: 0; width/height: 100%; object-fit: cover;`), each with a driven `opacity` and `transition: opacity .25s linear`.
  - A fixed gradient scrim over the images: `linear-gradient(180deg, rgba(14,17,11,.62) 0%, rgba(14,17,11,.12) 40%, rgba(14,17,11,.78) 100%)`.
  - Eyebrow label pinned top-left at `top:96px; left:clamp(20px,5vw,72px)` — a 56px×1px `#c2a069` rule + spaced-caps text.
  - Caption block pinned bottom (`left/right: clamp(20px,5vw,72px); bottom: clamp(48px,9vh,92px)`): time (italic serif), title (large serif), description, then a progress bar and four scene labels.

- **Components**:
  - **Eyebrow** — text "A DAY AT LONG POND", 11.5px, `letter-spacing:.45em`, weight 500, color `#e0c48f`; preceded by a 56×1px bar in `#c2a069`.
  - **Scene time** — `Cormorant Garamond`, italic, `clamp(18px,1.8vw,24px)`, color `#e8cf9c`, `margin-bottom:10px`.
  - **Scene title** — `Cormorant Garamond`, weight 400, `clamp(36px,5vw,72px)`, `line-height:1.05`, `max-width:14ch`, `text-wrap:balance`, color `#f2ede2`.
  - **Scene caption** — 14px, weight 300, `line-height:1.7`, `letter-spacing:.06em`, `max-width:52ch`, color `rgba(242,237,226,.75)`, `margin-top:14px`.
  - **Progress track** — `height:1px; background:rgba(242,237,226,.18)`, `margin-top:28px`.
  - **Progress fill** — absolute, `background:#c2a069`, `width` = scroll progress %, `transition: width .2s linear`.
  - **Scene labels row** — MORNING / CEREMONY / GOLDEN HOUR / LAST DANCE, 9.5px, `letter-spacing:.3em`, `rgba(242,237,226,.45)`, `justify-content:space-between`, `margin-top:10px`.

## Interactions & Behavior
- **Scroll tracking**: A passive `scroll` listener reads the section's `getBoundingClientRect()`. Progress `p = clamp(-rect.top / (rect.height - innerHeight), 0, 1)` — 0 when the section's top hits the viewport top, 1 when its bottom does.
- **Scene mapping**: `seg = p * 4` positions the user across four scenes. Active scene = `clamp(floor(seg), 0, 3)` and drives the caption text.
- **Cross-fade**: each image `i` (0-based) gets opacity `clamp(1 - max(0, |seg - (i+0.5)| - 0.35) * 4, 0, 1)`. Each scene is fully opaque within a plateau around its center and fades over the transition zone. The `.25s` CSS opacity transition smooths the stepped state updates.
- **Progress bar** fills `p * 100%`.
- **Performance**: state only updates when progress changes by > 0.002 to avoid excess re-renders. Listener is `{ passive: true }` and removed on unmount.
- **Reduced motion**: recommended enhancement — if `prefers-reduced-motion: reduce`, collapse the section to a static single hero image with the final caption (not implemented in the prototype).

## State Management
- One value: `dayP` — scroll progress `0 → 1` for this section.
- Trigger: window `scroll`. Everything else (active scene, opacities, bar width, caption) is derived from `dayP` at render time — keep it derived, don't store per-scene state.
- No data fetching. The `scenes` array (time/title/caption) is static content, easy to move to CMS/props.

## Design Tokens
Colors:
- Section background: `#0e110b`
- Primary text / cream: `#f2ede2`
- Accent gold (bars, progress fill): `#c2a069`
- Light gold (eyebrow, time): `#e0c48f` / `#e8cf9c`
- Muted cream: `rgba(242,237,226,.75)` (caption), `rgba(242,237,226,.45)` (labels), `rgba(242,237,226,.18)` (track)
- Scrim: `rgba(14,17,11,.62 / .12 / .78)`

Typography:
- Serif display: `'Cormorant Garamond', serif` (weights 400/500; italic used for time)
- Sans / UI: `'Karla', sans-serif` (weights 300–600)
- Google Fonts import included in the file `<head>`.

Spacing / sizing:
- Section height `420vh` (≈ `100vh × (scenes + 1)`)
- Horizontal inset: `clamp(20px, 5vw, 72px)`
- Eyebrow top offset: `96px`; caption bottom: `clamp(48px, 9vh, 92px)`
- Progress bar height: `1px`

Timing:
- Image opacity transition: `.25s linear`
- Progress fill transition: `.2s linear`

## Tuning
- **More/fewer scenes**: edit the `scenes` array, add/remove matching `<img>` tags, change `* 4` and `clamp(floor(seg), 0, N-1)` to the scene count, and set section height ≈ `100vh × (scenes + 1)`.
- **Scroll speed**: taller section = slower, more deliberate cross-fades.
- **Plateau vs. fade ratio**: the `-0.35` and `*4` constants in the opacity formula control how long each image holds full opacity vs. how fast it fades. Larger `0.35` = longer hold; larger multiplier = snappier fade.

## Assets
The prototype references the client's current-site photos (Wix CDN URLs) as placeholders for four moments: morning at the estate home, vows under the oaks, golden hour over the pond, last dance in the barn. **Replace with the venue's original full-resolution photography** for production — ideally one strong image per moment, shot to roughly the same 16:9-ish framing. Recommended: serve responsive `srcset` sizes and lazy-load scenes 2–4.

## Files
- `day_at_long_pond.html` — standalone, runnable prototype of this section (vanilla JS scroll logic; no build step).
- Original context: this section lives in `Long Pond Plantation.dc.html` (the full homepage prototype) in the parent project.
